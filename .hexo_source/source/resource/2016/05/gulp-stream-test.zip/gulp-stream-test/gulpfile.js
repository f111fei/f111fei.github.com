var es = require('event-stream');
var through = require('through2');
var rimraf = require('rimraf');
var gulp = require('gulp');
var gutil = require('gulp-util');
var File = gutil.File;

function use_es_through() {
	var contents = [];

	return es.through(function (file) {
		gutil.log('I am: ' + file.relative);
		contents.push(file.contents);
		contents.push(new Buffer('\n'));
	}, function () {
		var joinedContents = Buffer.concat(contents);
		var output = new File();
		output.contents = joinedContents;
		output.path = 'out.txt';
		this.emit('data', output);

		gutil.log('It is concated');
		this.emit('end');
	});
}

function use_es_map() {
	var contents = [];

	var input = es.through();
	var output = input
		.pipe(es.map(function (file, cb) {
			gutil.log('I am: ' + file.relative);
			contents.push(file.contents);
			contents.push(new Buffer('\n'));
			cb();
		}))
		.pipe(es.through(null, function () {
			var joinedContents = Buffer.concat(contents);
			var output = new File();
			output.contents = joinedContents;
			output.path = 'out.txt';
			this.emit('data', output);

			gutil.log('It is concated');
			this.emit('end');
		}));
	return es.duplex(input, output);
}

function use_through2_obj() {
	var contents = [];

	return through.obj(function (file, enc, cb) {
		gutil.log('I am: ' + file.relative);
		contents.push(file.contents);
		contents.push(new Buffer('\n'));
		cb();
	}, function (cb) {
		var joinedContents = Buffer.concat(contents);
		var output = new File();
		output.contents = joinedContents;
		output.path = 'out.txt';
		this.push(output);

		gutil.log('It is concated');
		cb();
	});
}

function concat(fn) {
	return function () {
		return gulp.src(['media/**/*.txt'])
			.pipe(fn())
			.pipe(gulp.dest('dist'));
	};
}

gulp.task('clean', function (cb) {
	rimraf('dist', cb);
});

gulp.task('concat1', ['clean'], concat(use_es_through));
gulp.task('concat2', ['clean'], concat(use_es_map));
gulp.task('concat3', ['clean'], concat(use_through2_obj));

gulp.task('default', function () {
	var first;

	return gulp.src(['media/**/*.txt'])
		.pipe(es.through(function (file) {
			gutil.log('pipe1: ' + file.relative);
			if (!first) {
				first = file;
			} else {
				this.emit('data', file);
			}
		}, function () {
			var self = this;
			gutil.log('It is first end');
			setTimeout(function () {
				self.push(first);
				self.emit('end');
			}, 1000);
		}))
		.pipe(es.map(function (file, cb) {
			gutil.log('pipe2: ' + file.relative);
			setTimeout(function () {
				cb(null, file);
			}, 2000);
		}))
		.pipe(es.through(function (file) {
			gutil.log('pipe3: ' + file.relative);
			this.emit('data', file);
		}, function () {
			gutil.log('It is last end');
			this.emit('end');
		}))
		.pipe(gulp.dest('dist'));
});